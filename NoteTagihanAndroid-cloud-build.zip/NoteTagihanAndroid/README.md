# Note Tagihan – Android

Proyek Android Studio untuk membungkus aplikasi Note Tagihan sebagai aplikasi Android offline.

## Membuat APK tanpa laptop (menggunakan GitHub Actions)
1. Buat akun atau masuk ke https://github.com melalui browser HP.
2. Buat repository baru bernama `NoteTagihan` (boleh Public atau Private).
3. Ekstrak ZIP proyek ini di HP.
4. Pada repository GitHub, pilih **Add file > Upload files**, lalu unggah seluruh isi folder proyek dengan struktur folder tetap terjaga. Pastikan folder `.github/workflows` ikut terunggah. Jika pemilih file HP tidak dapat mengunggah folder bertingkat, gunakan GitHub Codespaces atau komputer untuk mengunggah struktur proyek.
5. Setelah file masuk ke branch `main`, buka tab **Actions** pada repository.
6. Pilih workflow **Build Note Tagihan APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
7. Tunggu sampai proses selesai dengan tanda hijau. Buka hasil run, cari bagian **Artifacts**, lalu unduh `NoteTagihan-APK`.
8. Ekstrak hasil unduhan ZIP dan buka `app-debug.apk` untuk memasang aplikasi. Jika Android meminta izin, izinkan instalasi aplikasi dari sumber tersebut.

## Membuat APK dengan Android Studio
1. Buka folder proyek ini melalui Android Studio.
2. Tunggu Gradle Sync selesai. Pasang Android SDK Platform 35 jika diminta.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Fitur
- Tambah, edit, dan hapus pengeluaran.
- Pengelompokan otomatis per tanggal.
- Periode Senin–Minggu dan riwayat mingguan.
- Total klaim sinkron dengan rekap yang disalin.
- Penyimpanan lokal melalui `localStorage` WebView.
- Salin klaim memakai ClipboardManager Android.
- Ekspor JSON sebagai cadangan.

## Catatan
- ZIP ini adalah proyek sumber dengan workflow build cloud, bukan APK yang sudah dikompilasi.
- Build cloud membutuhkan akun GitHub dan unggahan proyek ke repository.
- Data disimpan di penyimpanan aplikasi pada perangkat. Menghapus data aplikasi dapat menghapus data lokal; ekspor JSON secara berkala.
- Aplikasi tidak membutuhkan koneksi internet untuk fitur utamanya.
